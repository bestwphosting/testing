<?php
define( 'WP_CACHE', true );



/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mensunder_wp_fqis4');

/** MySQL database username */
define('DB_USER', 'mensunder_wp_k23pq');

/** MySQL database password */
define('DB_PASSWORD', '4kor8%WHk?%9?g7f');

/** MySQL hostname */
define('DB_HOST', 'localhost:3306');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'J9A0FBHn|qN02z5b;KL2X[q%|2]7i/2IO46(16329]pMjFqn:&(Ei6@z(jsK5#!7');
define('SECURE_AUTH_KEY', 'A680WWZm~;)JY2S36*L[uS7jf@f5j1E4!z0JaGF1ACJn586Z]N]3w5V0(p4y@;1S');
define('LOGGED_IN_KEY', 'p2SAdwj|3@Evfx+bC9-pju8%0iF*KW~7LU*g2r2/78Lk5F(x7RB(yGT6048R)6#G');
define('NONCE_KEY', '5+2D/b0%Ivs:)6!2E0YrU)P+/1w|Su5|6J17pY!8b1dI3Roj|-0UsVSq9H86%tz+');
define('AUTH_SALT', 'Q&o(FHH(n(P4TV50@f-67]u+))[2a:RO(%4J4DWTk57Cpuu7~%m%6zgr~2191a|B');
define('SECURE_AUTH_SALT', '!:17tMT3HI;9GI86pPth~P!a+h2;JD#@9439]S!);7eS!3D~UvyN5e9fqh51@l!O');
define('LOGGED_IN_SALT', '6xD9%Os!k#6+6*%()l!]]/77L9J3]4-+gi7q8#r192|/WW9Zb&jNJ5A)4!~47++O');
define('NONCE_SALT', '1~yOpAbJ*])u*308Oe!4+dCMTiR@ex-:p[vO]&xgLv8eWW4Mfw4;X|%!9hd8ek]4');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'N1IoqiD_';


define('WP_ALLOW_MULTISITE', true);
define( 'WP_CACHE_KEY_SALT', 'dd62eb3e82d18e7581af112cf9b4f4cc' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
